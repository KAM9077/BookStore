function last (arr){
    
    var x=document.getElementByTagName('h1')[0] ;
x.textContent=arr[arr.length-1]
} 
arr2=[1,2,3]
last(arr2);

function go() {
 document.write("Hello World!");
}